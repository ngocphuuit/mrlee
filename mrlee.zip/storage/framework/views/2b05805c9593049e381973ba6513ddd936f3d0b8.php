<div class="box">
    <div class="box-header">

        <h3 class="box-title"></h3>

        <span style="position: absolute;left: 10px;top: 5px;">
            <?php echo $grid->renderHeaderTools(); ?>

        </span>

        <div class="box-tools">
            <?php echo $grid->renderFilter(); ?>

            <?php echo $grid->renderExportButton(); ?>

            <?php echo $grid->renderCreateButton(); ?>

        </div>

    </div>
    <!-- /.box-header -->
    <div class="box-footer">
        <ul class="mailbox-attachments clearfix">
            <?php $__currentLoopData = $grid->rows(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <span class="mailbox-attachment-icon has-img">
                        <?php echo $row->column('image'); ?>

                    </span>
                    <div class="mailbox-attachment-info">
                        <a href="#" class="mailbox-attachment-name">
                            <?php echo $row->column('title'); ?>

                        </a>
                        <br />
                        <?php echo $row->column('description'); ?>

                        <br />
                        <span class="mailbox-attachment-size">
                              <?php echo $row->column('__row_selector__'); ?>

                            <span class="pull-right">
                                <?php echo $row->column('__actions__'); ?>

                            </span>
                        </span>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>
    <div class="box-footer clearfix">
        <?php echo $grid->paginator(); ?>

    </div>
    <!-- /.box-body -->
</div>