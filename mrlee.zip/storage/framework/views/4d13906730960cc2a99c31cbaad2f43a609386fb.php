<input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" class="<?php echo e($class); ?>" <?php echo $attributes; ?> />
