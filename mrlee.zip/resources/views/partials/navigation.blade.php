<nav class="navbar">
    <div class="container">
        <div class="navbar-header">
            <button class="collapsed navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-example-js-navbar-scrollspy">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#home" class="navbar-brand"><img src="/img/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse bs-example-js-navbar-scrollspy">
            <ul id="nav" class="nav navbar-nav">
                <li><a href="#home">Trang chủ</a></li>
                <li><a href="#gallery">Album</a></li>
                <li><a href="#managent">Dịch Vụ</a></li>
                <li><a href="#blog">Blog</a></li>
                <li><a href="#story">Giới Thiệu</a></li>
                <li><a href="#event">Bảng giá</a></li>
                <li><a href="#contact">Liên Hệ</a></li>
            </ul>
        </div>
    </div>
</nav>